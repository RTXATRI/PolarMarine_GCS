# PolarMarine GCS Python Backend

FastAPI 后端统一管理固定设备名册、连接配置、每设备 ROSBridge 会话、真实 MAVROS 状态、虚拟任务和 WebSocket 推送。

## 运行

```powershell
conda activate GCS
cd backend
python -m pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

服务按单进程、单 worker 运行，避免多个进程重复持有同一串口。开发时使用 `--reload` 会重启进程，已打开的连接也会随之释放并恢复为未连接。

## 测试

```powershell
conda run -n GCS pytest -q
```

## 连接接口

- `GET /api/connections/serial-ports`
- `GET /api/connections/network-candidates?port=9090`
- `POST /api/robots/{robot_id}/connection`
- `DELETE /api/robots/{robot_id}/connection`

串口请求示例：

```json
{"method":"serial","port":"COM3","baudRate":115200}
```

网络请求示例：

```json
{"method":"network","host":"192.168.1.20","port":9090}
```

设备配置以原子替换方式写入 `runtime/device_profiles.json`，只保存配置，不保存句柄、在线状态、遥测或错误状态。

- 所有设备的普通网络地址都会真实连接对应 ROSBridge，并订阅 `/gcs/robot_state`。收到首条合法状态前保持“连接中”。
- `SmartDock-1` 手工输入测试地址 `192.0.2.42:9090` 时会立即生成测试状态；可通过 `DOCK_TEST_IP` 覆盖该地址。
- 串口连接仅保持真实句柄，协议数据处理尚未接入。
- PX4 设备连接成功后为 `dataMode=live`、`commandMode=virtual`：状态来自 MAVROS，通用控制、参数和任务不会向飞控发布命令。CL-USV 的电磁固定是独立硬件动作，会复用当前 ROSBridge 会话发布继电器命令。

机载端需要以约 2 Hz 发布 `std_msgs/String`：

```json
{
  "schemaVersion": 1,
  "robotId": "Hexa-UAV",
  "timestamp": "2026-07-17T09:00:00Z",
  "data": {
    "sourceConnected": true,
    "battery": 82,
    "mode": "手动",
    "px4Mode": "POSCTL",
    "missionStatus": "空闲",
    "linkStatus": "正常",
    "latencyMs": null,
    "packetLoss": null,
    "rssi": null,
    "lat": 30.2755,
    "lon": 120.157,
    "altitude": 12.4,
    "speed": 0.35,
    "heading": 86.2,
    "unlocked": false,
    "relayEnabled": null,
    "alarm": null
  }
}
```

`robotId` 必须与上位机当前设备一致。GPS 缺失、不成对、非数值、非有限值、越界或为 `(0, 0)` 时，后端使用在此前展示位置基础上继续向正北平移约 150 米、相对安徽大学磬苑校区附近原布局累计北移约 950 米的稳定展示坐标，其他遥测仍正常更新。CL-USV 将 `relayEnabled` 按布尔值上报；字段缺失时整机仍可连接，但电磁固定按钮保持未知且不可操作。后端忽略消息里的任务状态和链路指标：任务状态由上位机模拟，延迟、丢包和 RSSI 在没有真实来源前保持未知。连续 3 秒没有合法状态会清空实时字段，并按 1/2/4 秒重试三次。

CL-USV 电磁固定调用 `POST /api/commands/electromagnetic-fix`，请求体为 `{"robotId":"CL-USV","enabled":true}`。后端向 `/usv_std/relay/set_enabled` 发布 `std_msgs/Bool`，并等待后续汇总状态中的 `relayEnabled` 确认。可通过 `USV_RELAY_COMMAND_TOPIC` 和 `USV_RELAY_CONFIRMATION_TIMEOUT_SEC` 调整话题与确认超时。

示例真机地址 `192.168.1.249:9090` 直接在对应设备的连接面板填写，不需要修改后端全局 IP。后端应保持单进程、单 worker；设备 IP 改变时重新填写并连接即可。
