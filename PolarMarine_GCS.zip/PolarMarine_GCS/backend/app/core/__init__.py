"""Core backend configuration."""
