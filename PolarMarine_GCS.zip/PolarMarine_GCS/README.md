# PolarMarine GCS 无人设备上位机

Vue 3 + FastAPI 的 Windows Web 上位机。Python 后端是设备名册、连接状态、连接配置和遥测数据的唯一数据源；前端启动后会自动连接后端，不再运行独立 mock 名册或前端遥测 tick。

## 启动

需要 Python/Conda、Node.js 18+ 和 npm。建议分别打开两个 PowerShell 窗口。

后端：

```powershell
conda activate GCS
cd backend
python -m pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

前端：

```powershell
npm.cmd install
npm.cmd run dev
```

浏览器打开 Vite 输出的地址，通常是 <http://127.0.0.1:5173>。生产构建执行：

```powershell
npm.cmd run build
```

默认地址可以在根目录 `.env` 中覆盖：

```dotenv
VITE_GCS_API_BASE=http://127.0.0.1:8000/api
VITE_GCS_WS_URL=ws://127.0.0.1:8000/ws/telemetry
```

## 连接行为

- 后端每次启动时，5 台固定设备均为“未连接”；实时字段、轨迹和运行任务为空，保存的连接配置只用于表单预填。
- 未连接设备在总览的视频区域显示连接配置面板，不会枚举、授权或打开本机摄像头。
- 串口连接会真实枚举并打开端口，以 8-N-1 保持句柄。本阶段不解析设备协议，因此连接后实时数据仍显示未知，控制接口会返回 `DATA_CHANNEL_UNAVAILABLE`。
- UAV/USV 的网络连接会真实连接设备配置中的 ROSBridge，并等待 `/gcs/robot_state` 合法首帧；示例真机可填写 `192.168.1.249:9090`。`robotId` 不匹配、MAVROS 未连接、首帧超时或消息非法都会闭环显示错误。
- PX4 设备的电池、模式、位置、高度、速度、航向和解锁状态来自真实 MAVROS 汇总数据；任务、手动控制、参数和急停仍为明确标记的上位机模拟反馈，不会向飞控发布命令。
- `SmartDock-1` 保持原有网络虚拟状态；串口设备仍只打开硬件句柄而不解析协议。
- 网络搜索会在活动的私有 IPv4 网段中探测表单端口；无结果时仍可手工输入。
- 主动断开会清空运行数据且不报警；实时状态连续 3 秒中断后按 1/2/4 秒有限重连，耗尽后进入错误状态并只生成一次报警。
- 当前设备按 `connected`、`connecting`、其他状态稳定排序，名册的持久顺序不变。
- 后端或 WebSocket 失联后，前端卸载摄像头、停止媒体轨道、禁用控制并自动重连。

连接配置保存在 `backend/runtime/device_profiles.json`。该目录是运行时输出，未纳入 Git。

## 验证

```powershell
cd backend
conda run -n GCS pytest -q

cd ..
npm.cmd test
npm.cmd run type-check
npm.cmd run build
```

这里使用 `npm.cmd`，可避开部分 Windows PowerShell 环境禁止执行 `npm.ps1` 的策略限制。

真实串口验收需分别选取一个空闲 COM 口和一个已被其他程序占用的 COM 口。串口支持的波特率为 `9600/19200/38400/57600/115200`，默认 `115200`。

## 主要接口

```text
GET    /api/health
GET    /api/robots
GET    /api/connections/serial-ports
GET    /api/connections/network-candidates?port=9090
POST   /api/robots/{robot_id}/connection
DELETE /api/robots/{robot_id}/connection
WS     /ws/telemetry
```

控制、任务和参数接口只接受具有操作通道的设备。PX4 网络连接提供虚拟操作通道，HTTP 响应和日志不会修改真实遥测；串口连接等待后续协议接入。

## 技术栈

- Vue 3、TypeScript、Vite、Element Plus、Pinia
- FastAPI、Pydantic、WebSocket
- pyserial（串口枚举/占用）、psutil（局域网接口发现）
- roslibpy（每设备 ROSBridge 会话）、pyserial（串口枚举/占用）、psutil（局域网接口发现）
- ECharts、Canvas 2D、MediaDevices/getUserMedia
